import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {environment} from '../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  constructor(private http: HttpClient,) { }
  buscarPersonajeStarWars(nombre:string|null) :any{
    return this.http
      .get(environment.swapi_url + "people/?search=" + nombre).toPromise();   
  }
  buscarPersonajeRickMorty(nombre:string|null) :any{
    return this.http
      .get( environment.rick_and_morty_url + "character/?name=" + nombre ).toPromise();  
      
  }
}
