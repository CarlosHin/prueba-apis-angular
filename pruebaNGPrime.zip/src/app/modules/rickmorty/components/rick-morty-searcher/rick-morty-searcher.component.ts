import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SearchService } from 'src/app/search.service';

@Component({
  selector: 'app-rick-morty-searcher',
  templateUrl: './rick-morty-searcher.component.html',
  styleUrls: ['./rick-morty-searcher.component.css']
})
export class RickMortySearcherComponent implements OnInit {
  name:string|null ="";
  lista:Object[]=[];
  loading:boolean=false;
  constructor(
    private buscador:SearchService,
    private activatedroute:ActivatedRoute
    ) { }

  ngOnInit(): void {
    if(this.activatedroute.snapshot.paramMap.get("name")){
      this.name=this.activatedroute.snapshot.paramMap.get("name")
      this.buscar();
    }
  }
  sleep(ms:number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  async buscar(){
    this.loading = true;
    this.lista = [];
    await this.sleep(500);
    let resultado = await this.buscador.buscarPersonajeRickMorty(this.name);
    this.loading = false;
    this.lista = resultado.results;
    console.log(this.lista)

  }
}
