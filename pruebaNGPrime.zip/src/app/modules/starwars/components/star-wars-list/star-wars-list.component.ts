import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-star-wars-list',
  templateUrl: './star-wars-list.component.html',
  styleUrls: ['./star-wars-list.component.css']
})
export class StarWarsListComponent implements OnInit {
  @Input() lista:any[]=[];
  constructor() { }

  ngOnInit(): void {
  }

}
